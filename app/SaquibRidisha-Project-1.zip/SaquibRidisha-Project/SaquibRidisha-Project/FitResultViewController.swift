import UIKit

class FitResultViewController: UIViewController {

    let scrollView = UIScrollView()
    let stackView = UIStackView()

    let titleLabel = UILabel()
    let fitImageView = UIImageView()
    let overallRatingLabel = UILabel()

    let outfitTypeLabel = UILabel()
    let patternLabel = UILabel()
    let colorLabel = UILabel()
    let shoesLabel = UILabel()
    let accessoriesLabel = UILabel()
    let vibeMatchLabel = UILabel()

    let commentLabel = UILabel()
    let saveToHistoryButton = UIButton(type: .system)
    let rateAnotherFitButton = UIButton(type: .system)
    let strictnessLabel = UILabel()

    var selectedImage: UIImage?
    var ratingResult: FitRatingResult?
    var occasion: String?
    var strictness: FitStrictness = .easy

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        displayResult()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Fit Result"

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        stackView.translatesAutoresizingMaskIntoConstraints = false

        stackView.axis = .vertical
        stackView.spacing = 14
        stackView.alignment = .fill

        view.addSubview(scrollView)
        scrollView.addSubview(stackView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            stackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor, constant: 22),
            stackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor, constant: -22),
            stackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor, constant: -24),
            stackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor, constant: -44)
        ])

        titleLabel.text = "Fit Result"
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 36) ?? UIFont.systemFont(ofSize: 36, weight: .bold)
        titleLabel.textColor = .label

        fitImageView.contentMode = .scaleAspectFill
        fitImageView.clipsToBounds = true
        fitImageView.layer.cornerRadius = 16
        fitImageView.backgroundColor = .secondarySystemBackground

        NSLayoutConstraint.activate([
            fitImageView.heightAnchor.constraint(equalTo: fitImageView.widthAnchor)
        ])

        overallRatingLabel.textAlignment = .center
        overallRatingLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        overallRatingLabel.textColor = .systemPink

        commentLabel.numberOfLines = 0
        commentLabel.textAlignment = .center
        commentLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        commentLabel.textColor = .systemTeal

        styleScoreLabel(outfitTypeLabel)
        styleScoreLabel(patternLabel)
        styleScoreLabel(colorLabel)
        styleScoreLabel(shoesLabel)
        styleScoreLabel(accessoriesLabel)
        styleScoreLabel(vibeMatchLabel)

        styleButton(saveToHistoryButton, title: "Save to History", color: UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.9))
        styleButton(rateAnotherFitButton, title: "Rate Another Fit", color: UIColor.systemPink.withAlphaComponent(0.20))
        rateAnotherFitButton.setTitleColor(.systemPink, for: .normal)

        saveToHistoryButton.addTarget(self, action: #selector(saveToHistoryPressed), for: .touchUpInside)
        rateAnotherFitButton.addTarget(self, action: #selector(rateAnotherFitPressed), for: .touchUpInside)

        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(strictnessLabel)
        stackView.addArrangedSubview(fitImageView)
        stackView.addArrangedSubview(overallRatingLabel)
        stackView.addArrangedSubview(outfitTypeLabel)
        stackView.addArrangedSubview(patternLabel)
        stackView.addArrangedSubview(colorLabel)
        stackView.addArrangedSubview(shoesLabel)
        stackView.addArrangedSubview(accessoriesLabel)
        stackView.addArrangedSubview(vibeMatchLabel)
        stackView.addArrangedSubview(commentLabel)
        stackView.addArrangedSubview(saveToHistoryButton)
        stackView.addArrangedSubview(rateAnotherFitButton)
        strictnessLabel.textAlignment = .center
        strictnessLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        strictnessLabel.textColor = .secondaryLabel
    }

    func styleScoreLabel(_ label: UILabel) {
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textColor = .label
    }

    func styleButton(_ button: UIButton, title: String, color: UIColor) {
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont(name: "SnellRoundhand-Bold", size: 25) ?? UIFont.systemFont(ofSize: 22, weight: .semibold)
        button.backgroundColor = color
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 12
        button.clipsToBounds = true

        NSLayoutConstraint.activate([
            button.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    func displayResult() {
        fitImageView.image = selectedImage

        guard let result = ratingResult else { return }

        overallRatingLabel.text = String(format: "Overall Rating: %.1f/10", result.overallRating)
        let modeText = strictness == .easy ? "Easy Mode" : "Normal Mode"
        strictnessLabel.text = "Rating Mode: \(modeText)"

        outfitTypeLabel.text = "Outfit Type: \(result.outfitTypeScore)/10"
        patternLabel.text = "Patterns: \(result.patternScore)/10"
        colorLabel.text = "Colors: \(result.colorScore)/10"
        shoesLabel.text = "Shoes: \(result.shoesScore)/10"
        accessoriesLabel.text = "Accessories: \(result.accessoriesScore)/10"
        vibeMatchLabel.text = "Vibe Match: \(result.vibeMatchScore)/10"

        commentLabel.text = result.comment
    }

    @objc func saveToHistoryPressed() {

        guard let result = ratingResult else { return }

        let imageData = selectedImage?.jpegData(compressionQuality: 0.8)

        let savedFit = SavedFit(
            id: UUID(),
            imageData: imageData,
            occasion: occasion ?? "Unknown",
            overallRating: result.overallRating,
            outfitTypeScore: result.outfitTypeScore,
            patternScore: result.patternScore,
            colorScore: result.colorScore,
            shoesScore: result.shoesScore,
            accessoriesScore: result.accessoriesScore,
            vibeMatchScore: result.vibeMatchScore,
            comment: result.comment,
            date: Date()
        )

        FitHistoryManager.shared.saveFit(savedFit)

        let alert = UIAlertController(
            title: "Saved",
            message: "Fit saved to history.",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    @objc func rateAnotherFitPressed() {
        if let rateVC = navigationController?.viewControllers.first as? RateViewController {
            rateVC.shouldResetForm = true
        }

        navigationController?.popToRootViewController(animated: true)
    }
}
