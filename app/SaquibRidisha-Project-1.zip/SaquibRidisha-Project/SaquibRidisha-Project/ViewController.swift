//
//  ViewController.swift
//  SaquibRidisha-Project
//
//  Created by Saquib, Ridisha N on 3/31/26.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var bowImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        overrideUserInterfaceStyle = .light
    }

    func styleUI() {
        view.backgroundColor = UIColor.systemBackground

        titleLabel.text = "FitRater"
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 38) ?? UIFont.systemFont(ofSize: 38, weight: .bold)
        titleLabel.textColor = .label

        loginButton.setTitle("Log In", for: .normal)
        signUpButton.setTitle("Sign Up", for: .normal)

        loginButton.titleLabel?.font = UIFont.systemFont(ofSize: 22, weight: .semibold)
        signUpButton.titleLabel?.font = UIFont.systemFont(ofSize: 22, weight: .semibold)

        loginButton.backgroundColor = .clear
        signUpButton.backgroundColor = .clear

        loginButton.setTitleColor(UIColor.systemTeal, for: .normal)
        signUpButton.setTitleColor(UIColor.systemTeal, for: .normal)

        let lavender = UIColor(red: 0.78, green: 0.69, blue: 0.90, alpha: 1.0)

        loginButton.configurationUpdateHandler = { button in
            button.backgroundColor = .clear
            button.setTitleColor(button.isHighlighted ? lavender : UIColor.systemTeal, for: .normal)
        }

        signUpButton.configurationUpdateHandler = { button in
            button.backgroundColor = .clear
            button.setTitleColor(button.isHighlighted ? lavender : UIColor.systemTeal, for: .normal)
        }
    }

    @IBAction func loginPressed(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            show(loginVC, sender: self)
        }
    }

    @IBAction func signUpPressed(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let signUpVC = storyboard.instantiateViewController(withIdentifier: "SignUpViewController") as? SignUpViewController {
            show(signUpVC, sender: self)
        }
    }
}

