import UIKit
import FirebaseAuth

class HistoryDetailViewController: UIViewController {

    let scrollView = UIScrollView()
    let stackView = UIStackView()

    let fitImageView = UIImageView()
    let overallRatingLabel = UILabel()
    let occasionLabel = UILabel()
    let outfitTypeLabel = UILabel()
    let patternLabel = UILabel()
    let colorLabel = UILabel()
    let shoesLabel = UILabel()
    let accessoriesLabel = UILabel()
    let vibeMatchLabel = UILabel()
    let commentLabel = UILabel()
    let deleteButton = UIButton(type: .system)

    var savedFit: SavedFit?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        displayFit()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Fit Details"

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        stackView.translatesAutoresizingMaskIntoConstraints = false

        stackView.axis = .vertical
        stackView.spacing = 14
        stackView.alignment = .fill

        view.addSubview(scrollView)
        scrollView.addSubview(stackView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            stackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor, constant: 22),
            stackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor, constant: -22),
            stackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor, constant: -24),
            stackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor, constant: -44)
        ])

        fitImageView.contentMode = .scaleAspectFill
        fitImageView.clipsToBounds = true
        fitImageView.layer.cornerRadius = 16
        fitImageView.backgroundColor = .secondarySystemBackground

        NSLayoutConstraint.activate([
            fitImageView.heightAnchor.constraint(equalTo: fitImageView.widthAnchor)
        ])

        overallRatingLabel.textAlignment = .center
        overallRatingLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        overallRatingLabel.textColor = .systemPink

        commentLabel.numberOfLines = 0
        commentLabel.textAlignment = .center
        commentLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        commentLabel.textColor = .systemTeal

        styleScoreLabel(occasionLabel)
        styleScoreLabel(outfitTypeLabel)
        styleScoreLabel(patternLabel)
        styleScoreLabel(colorLabel)
        styleScoreLabel(shoesLabel)
        styleScoreLabel(accessoriesLabel)
        styleScoreLabel(vibeMatchLabel)

        styleDeleteButton(deleteButton)
        deleteButton.addTarget(self, action: #selector(deleteFitPressed), for: .touchUpInside)

        stackView.addArrangedSubview(fitImageView)
        stackView.addArrangedSubview(overallRatingLabel)
        stackView.addArrangedSubview(occasionLabel)
        stackView.addArrangedSubview(outfitTypeLabel)
        stackView.addArrangedSubview(patternLabel)
        stackView.addArrangedSubview(colorLabel)
        stackView.addArrangedSubview(shoesLabel)
        stackView.addArrangedSubview(accessoriesLabel)
        stackView.addArrangedSubview(vibeMatchLabel)
        stackView.addArrangedSubview(commentLabel)
        stackView.addArrangedSubview(deleteButton)
    }

    func styleScoreLabel(_ label: UILabel) {
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textColor = .label
    }

    func styleDeleteButton(_ button: UIButton) {
        button.setTitle("Delete Fit", for: .normal)
        button.titleLabel?.font = UIFont(name: "SnellRoundhand-Bold", size: 25) ?? UIFont.systemFont(ofSize: 22, weight: .semibold)
        button.backgroundColor = UIColor.systemPink.withAlphaComponent(0.20)
        button.setTitleColor(.systemPink, for: .normal)
        button.layer.cornerRadius = 12
        button.clipsToBounds = true

        NSLayoutConstraint.activate([
            button.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    func displayFit() {
        guard let fit = savedFit else { return }

        if let imageData = fit.imageData {
            fitImageView.image = UIImage(data: imageData)
        } else {
            fitImageView.image = UIImage(systemName: "photo")
        }

        overallRatingLabel.text = String(format: "Overall Rating: %.1f/10", fit.overallRating)
        occasionLabel.text = "Occasion: \(fit.occasion)"
        outfitTypeLabel.text = "Outfit Type: \(fit.outfitTypeScore)/10"
        patternLabel.text = "Patterns: \(fit.patternScore)/10"
        colorLabel.text = "Colors: \(fit.colorScore)/10"
        shoesLabel.text = "Shoes: \(fit.shoesScore)/10"
        accessoriesLabel.text = "Accessories: \(fit.accessoriesScore)/10"
        vibeMatchLabel.text = "Vibe Match: \(fit.vibeMatchScore)/10"
        commentLabel.text = fit.comment
    }

    @objc func deleteFitPressed() {
        triggerHaptic(style: .heavy)

        let alert = UIAlertController(
            title: "Delete Fit",
            message: "Are you sure you want to delete this fit?",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))

        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            guard let fit = self.savedFit else { return }
            self.triggerHaptic(style: .heavy)
            FitHistoryManager.shared.deleteFit(id: fit.id)
            self.navigationController?.popViewController(animated: true)
        }))

        present(alert, animated: true)
    }

    func triggerHaptic(style: UIImpactFeedbackGenerator.FeedbackStyle = .medium) {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        let enabled = UserDefaults.standard.object(forKey: "\(uid)_hapticsEnabled") as? Bool ?? true

        if enabled {
            let generator = UIImpactFeedbackGenerator(style: style)
            generator.impactOccurred()
        }
    }
}
