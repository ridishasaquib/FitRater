import UIKit

class FitScanViewController: UIViewController {

    let imageView = UIImageView()
    let titleLabel = UILabel()
    let bowStackView = UIStackView()

    var selectedImage: UIImage?
    var ratingResult: FitRatingResult?
    var occasion: String?
    var strictness: FitStrictness = .easy

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        startBowAnimation()
        goToResultAfterDelay()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Fit Scan"

        imageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        bowStackView.translatesAutoresizingMaskIntoConstraints = false

        imageView.image = selectedImage
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 18
        imageView.alpha = 0.35

        titleLabel.text = "Fit Scan in Progress..."
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 32) ?? UIFont.systemFont(ofSize: 32, weight: .bold)
        titleLabel.textColor = .label

        bowStackView.axis = .horizontal
        bowStackView.spacing = 18
        bowStackView.alignment = .center
        bowStackView.distribution = .equalSpacing

        for _ in 0..<3 {
            let bow = UIImageView(image: UIImage(named: "bowLogo"))
            bow.contentMode = .scaleAspectFit
            bow.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                bow.widthAnchor.constraint(equalToConstant: 45),
                bow.heightAnchor.constraint(equalToConstant: 45)
            ])
            bowStackView.addArrangedSubview(bow)
        }

        view.addSubview(imageView)
        view.addSubview(titleLabel)
        view.addSubview(bowStackView)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            imageView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 35),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 28),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -28),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor),

            bowStackView.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 40),
            bowStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    func startBowAnimation() {
        for (index, view) in bowStackView.arrangedSubviews.enumerated() {
            UIView.animate(
                withDuration: 0.55,
                delay: Double(index) * 0.18,
                options: [.repeat, .autoreverse, .curveEaseInOut],
                animations: {
                    view.transform = CGAffineTransform(translationX: 0, y: -18)
                }
            )
        }
    }

    func goToResultAfterDelay() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            if let resultVC = storyboard.instantiateViewController(withIdentifier: "FitResultViewController") as? FitResultViewController {
                resultVC.selectedImage = self.selectedImage
                resultVC.ratingResult = self.ratingResult
                resultVC.occasion = self.occasion
                resultVC.strictness = self.strictness
                self.navigationController?.pushViewController(resultVC, animated: true)
            }
        }
    }
}
