//
//  LoginViewController.swift
//  SaquibRidisha-Project
//
//  Created by Saquib, Ridisha N on 3/31/26.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var bowImageView: UIImageView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
        emailTextField.delegate = self
        passwordTextField.delegate = self
    }
    
    func styleUI() {
        view.backgroundColor = UIColor.systemBackground
        
        let softBlue = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.65)
        let pressedBlue = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.9)
        
        emailTextField.text = ""
        passwordTextField.text = ""
        
        emailTextField.keyboardType = .emailAddress
        emailTextField.autocapitalizationType = .none
        emailTextField.autocorrectionType = .no
        emailTextField.returnKeyType = .next
        passwordTextField.returnKeyType = .done
        
        passwordTextField.isSecureTextEntry = true
        passwordTextField.autocapitalizationType = .none
        passwordTextField.autocorrectionType = .no
        
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "email",
            attributes: [.foregroundColor: UIColor.gray]
        )
        
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "password",
            attributes: [.foregroundColor: UIColor.gray]
        )
        
        styleTextField(emailTextField)
        styleTextField(passwordTextField)
        
        loginButton.setTitle("Log In", for: .normal)
        loginButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        loginButton.backgroundColor = softBlue
        loginButton.setTitleColor(.white, for: .normal)
        loginButton.layer.cornerRadius = 12
        loginButton.clipsToBounds = true
        
        loginButton.configurationUpdateHandler = { button in
            button.backgroundColor = button.isHighlighted ? pressedBlue : softBlue
        }
    }
    
    func styleTextField(_ textField: UITextField) {
        textField.borderStyle = .none
        textField.backgroundColor = .secondarySystemBackground
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.systemGray4.cgColor
        
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 44))
        textField.leftView = paddingView
        textField.leftViewMode = .always
    }
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        overrideUserInterfaceStyle = .light
    }
    func applySavedThemeForCurrentUser() {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        let theme = UserDefaults.standard.object(forKey: "\(uid)_themeSelection") as? Int ?? 0
        let style: UIUserInterfaceStyle = (theme == 0) ? .light : .dark

        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.overrideUserInterfaceStyle = style
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
            loginPressed(loginButton)
        }
        return true
    }
    
    @IBAction func loginPressed(_ sender: UIButton) {
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let password = passwordTextField.text ?? ""
        guard !email.isEmpty, !password.isEmpty else {
            showAlert(title: "Missing Info", message: "Please enter email and password.")
            return
        }
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] result, error in
            guard let self = self else { return }
            if let _ = error {
                self.showAlert(title: "Log In Failed", message: "Invalid email or password.")
                return
            }
            self.applySavedThemeForCurrentUser()
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let tabBarVC = storyboard.instantiateViewController(withIdentifier: "MainTabBarController") as? UITabBarController {
                tabBarVC.modalPresentationStyle = .fullScreen
                self.present(tabBarVC, animated: true)
            }
        }
    }
}
