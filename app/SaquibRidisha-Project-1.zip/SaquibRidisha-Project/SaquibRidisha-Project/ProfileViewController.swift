
import UIKit
import FirebaseAuth

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate, UITextFieldDelegate {

    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var changePhotoButton: UIButton!

    
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var usernameTextField: UITextField!

    
    @IBOutlet weak var bioTextView: UITextView!
    
    
    @IBOutlet weak var avgScoreLabel: UILabel!
    @IBOutlet weak var bestScoreLabel: UILabel!
    @IBOutlet weak var totalFitsLabel: UILabel!
    
    @IBOutlet weak var editProfileButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var deleteProfileButton: UIButton!
    
    let bioPlaceholder = "Bio..."
    var previousUsername = ""
    private let usernameLimit = 7
    private let bioWordLimit = 25
    private var previousBio = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
        loadProfile()
        loadStats()
        setEditingMode(false)
    }

    func styleUI() {
        view.backgroundColor = .systemBackground
        title = "Profile"

        profileImageView.layer.cornerRadius = 12
        profileImageView.clipsToBounds = true
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.image = UIImage(systemName: "person.crop.circle")
        profileImageView.tintColor = .systemGray3
        profileImageView.backgroundColor = .secondarySystemBackground
        profileImageView.isUserInteractionEnabled = true

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(changePhotoTapped))
        profileImageView.addGestureRecognizer(tapGesture)

        usernameLabel.textAlignment = .center
        usernameLabel.font = UIFont.systemFont(ofSize: 22, weight: .medium)

        usernameTextField.delegate = self
        usernameTextField.borderStyle = .roundedRect
        usernameTextField.textAlignment = .center

        bioTextView.delegate = self
        bioTextView.layer.cornerRadius = 10
        bioTextView.layer.borderWidth = 1
        bioTextView.layer.borderColor = UIColor.systemGray4.cgColor
        bioTextView.font = UIFont.systemFont(ofSize: 18)
        bioTextView.backgroundColor = .secondarySystemBackground

        avgScoreLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        bestScoreLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        totalFitsLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        stylePrimaryButton(changePhotoButton)
        stylePrimaryButton(editProfileButton)
        styleDangerButton(deleteProfileButton)
        stylePrimaryButton(saveButton)
    }

    func stylePrimaryButton(_ button: UIButton) {
        button.layer.cornerRadius = 12
        button.clipsToBounds = true
        button.backgroundColor = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.65)
        button.setTitleColor(.white, for: .normal)
    }

    func styleDangerButton(_ button: UIButton) {
        button.layer.cornerRadius = 12
        button.clipsToBounds = true
        button.backgroundColor = UIColor.systemPink.withAlphaComponent(0.15)
        button.setTitleColor(.systemPink, for: .normal)
    }

    func loadProfile() {
        let email = Auth.auth().currentUser?.email ?? ""
        let generatedUsername = String((email.components(separatedBy: "@").first ?? "user").prefix(usernameLimit))

        let savedUsername = UserDefaults.standard.string(forKey: userKey("profile_username")) ?? generatedUsername
        let savedBio = UserDefaults.standard.string(forKey: userKey("profile_bio")) ?? ""

        previousUsername = savedUsername
        previousBio = savedBio

        usernameLabel.text = savedUsername
        usernameTextField.text = savedUsername
        usernameTextField.attributedPlaceholder = NSAttributedString(
            string: savedUsername,
            attributes: [.foregroundColor: UIColor.gray]
        )
        usernameTextField.textColor = .label

        if savedBio.isEmpty {
            bioTextView.text = bioPlaceholder
            bioTextView.textColor = .gray
        } else {
            bioTextView.text = savedBio
            bioTextView.textColor = .label
        }

        if let imageData = UserDefaults.standard.data(forKey: userKey("profile_image")),
           let image = UIImage(data: imageData) {
            profileImageView.image = image
            profileImageView.tintColor = nil
        } else {
            profileImageView.image = UIImage(systemName: "person.crop.circle")
            profileImageView.tintColor = .systemGray3
        }
    }

    func loadStats() {
        let avgScore = UserDefaults.standard.double(forKey: userKey("avg_score"))
        let bestScore = UserDefaults.standard.double(forKey: userKey("best_score"))
        let totalFits = UserDefaults.standard.integer(forKey: userKey("total_fits"))

        avgScoreLabel.text = String(format: "Avg Score: %.1f", avgScore)
        bestScoreLabel.text = String(format: "Best Score: %.1f", bestScore)
        totalFitsLabel.text = "Total Fits: \(totalFits)"
    }

    func setEditingMode(_ editing: Bool) {
        usernameLabel.isHidden = editing
        usernameTextField.isHidden = !editing

        saveButton.isHidden = !editing
        deleteProfileButton.isHidden = !editing
        changePhotoButton.isHidden = !editing

        editProfileButton.isHidden = editing

        bioTextView.isEditable = editing
        bioTextView.isSelectable = editing

        if editing {
            usernameTextField.becomeFirstResponder()
        } else {
            view.endEditing(true)
        }
    }
    func userKey(_ key: String) -> String {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        return "\(uid)_\(key)"
    }

    @IBAction func editProfilePressed(_ sender: UIButton) {
        triggerHaptic(style: .light)
        previousBio = (bioTextView.text == bioPlaceholder) ? "" : bioTextView.text
        usernameTextField.text = previousUsername
        usernameTextField.attributedPlaceholder = NSAttributedString(
            string: previousUsername,
            attributes: [.foregroundColor: UIColor.gray]
        )
        usernameTextField.textColor = .label
        if bioTextView.text == bioPlaceholder {
            bioTextView.text = ""
            bioTextView.textColor = .label
        }
        setEditingMode(true)
    }

    @IBAction func savePressed(_ sender: UIButton) {
        triggerHaptic(style: .medium)
        let newUsername = usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let bioText = bioTextView.text.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !newUsername.isEmpty else {
            usernameTextField.text = previousUsername
            showAlert(title: "Missing Name", message: "Please enter user.")
            return
        }

        guard newUsername.count <= usernameLimit else {
            usernameTextField.text = String(newUsername.prefix(usernameLimit))
            showAlert(title: "Username Too Long", message: "Username can only be \(usernameLimit) letters.")
            return
        }

        let bioWords = wordCount(for: bioText)
        guard bioWords <= bioWordLimit else {
            bioTextView.text = previousBio.isEmpty ? bioPlaceholder : previousBio
            bioTextView.textColor = previousBio.isEmpty ? .gray : .label
            showAlert(title: "Bio Too Long", message: "Bio can only have \(bioWordLimit) words.")
            return
        }

        previousUsername = newUsername
        usernameLabel.text = newUsername
        usernameTextField.text = newUsername
        usernameTextField.textColor = .gray
        UserDefaults.standard.set(newUsername, forKey: userKey("profile_username"))

        if bioText.isEmpty {
            previousBio = ""
            UserDefaults.standard.set("", forKey: userKey("profile_bio"))
            bioTextView.text = bioPlaceholder
            bioTextView.textColor = .gray
        } else {
            previousBio = bioText
            UserDefaults.standard.set(bioText, forKey: userKey("profile_bio"))
            bioTextView.text = bioText
            bioTextView.textColor = .label
        }

        setEditingMode(false)
    }

    @IBAction func deleteProfilePressed(_ sender: UIButton) {
        triggerHaptic(style: .heavy)
        let alert = UIAlertController(title: "Delete Profile", message: "Are you sure?", preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))

        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            self.triggerHaptic(style: .heavy)
            self.deleteAccount()
        }))

        present(alert, animated: true)
    }

    @IBAction func changePhotoButtonPressed(_ sender: UIButton) {
        triggerHaptic(style: .light)
        showPhotoActionSheet()
    }

    @objc func changePhotoTapped() {
        if !changePhotoButton.isHidden {
            showPhotoActionSheet()
        }
    }

    func showPhotoActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            actionSheet.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { _ in
                self.openImagePicker(sourceType: .photoLibrary)
            }))
        }

        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
                self.openImagePicker(sourceType: .camera)
            }))
        }

        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))

        if let popover = actionSheet.popoverPresentationController {
            popover.sourceView = changePhotoButton
            popover.sourceRect = changePhotoButton.bounds
        }

        present(actionSheet, animated: true)
    }

    func openImagePicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = sourceType
        picker.allowsEditing = true
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        let selectedImage = (info[.editedImage] ?? info[.originalImage]) as? UIImage

        if let image = selectedImage {
            profileImageView.image = image
            profileImageView.tintColor = nil

            if let imageData = image.jpegData(compressionQuality: 0.8) {
                UserDefaults.standard.set(imageData, forKey: userKey("profile_image"))
            }
        }

        dismiss(animated: true)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }

    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == bioPlaceholder {
            textView.text = ""
            textView.textColor = .label
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        let trimmedText = textView.text.trimmingCharacters(in: .whitespacesAndNewlines)

        if trimmedText.isEmpty {
            textView.text = bioPlaceholder
            textView.textColor = .gray
            return
        }

        let bioWords = wordCount(for: trimmedText)
        if bioWords > bioWordLimit {
            textView.text = previousBio.isEmpty ? bioPlaceholder : previousBio
            textView.textColor = previousBio.isEmpty ? .gray : .label
            showAlert(title: "Bio Too Long", message: "Bio can only have \(bioWordLimit) words.")
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.text == previousUsername {
            textField.textColor = .label
        }
    }

    func deleteAccount() {
        UserDefaults.standard.removeObject(forKey: userKey("profile_username"))
        UserDefaults.standard.removeObject(forKey: userKey("profile_bio"))
        UserDefaults.standard.removeObject(forKey: userKey("profile_image"))
        UserDefaults.standard.removeObject(forKey: userKey("avg_score"))
        UserDefaults.standard.removeObject(forKey: userKey("best_score"))
        UserDefaults.standard.removeObject(forKey: userKey("total_fits"))

        if let user = Auth.auth().currentUser {
            user.delete { error in
                if let error = error {
                    let alert = UIAlertController(title: "Delete Failed", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                    return
                }

                self.goToWelcomeScreen()
            }
        } else {
            goToWelcomeScreen()
        }
    }

    func goToWelcomeScreen() {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.overrideUserInterfaceStyle = .light
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let welcomeVC = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
            welcomeVC.modalPresentationStyle = .fullScreen
            present(welcomeVC, animated: true)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let currentText = textField.text,
              let textRange = Range(range, in: currentText) else {
            return true
        }

        let updatedText = currentText.replacingCharacters(in: textRange, with: string)

        if updatedText.count > usernameLimit {
            showAlert(title: "Username Too Long", message: "Username can only be \(usernameLimit) letters.")
            return false
        }

        return true
    }
    func wordCount(for text: String) -> Int {
        let words = text.split { $0.isWhitespace || $0.isNewline }
        return words.count
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    func triggerHaptic(style: UIImpactFeedbackGenerator.FeedbackStyle = .medium) {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        let enabled = UserDefaults.standard.object(forKey: "\(uid)_hapticsEnabled") as? Bool ?? true
        
        if enabled {
            let generator = UIImpactFeedbackGenerator(style: style)
            generator.impactOccurred()
        }
    }
}
