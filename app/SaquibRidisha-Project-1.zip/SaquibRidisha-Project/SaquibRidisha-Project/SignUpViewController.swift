//
//  SignUpViewController.swift
//  SaquibRidisha-Project
//
//  Created by Saquib, Ridisha N on 3/31/26.
//

import UIKit
import FirebaseAuth

class SignUpViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var bowImageView: UIImageView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
        emailTextField.delegate = self
        passwordTextField.delegate = self
    }
    
    func styleUI() {
        view.backgroundColor = UIColor.systemBackground
        
        let softBlue = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.65)
        let pressedBlue = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.9)
        
        emailTextField.text = ""
        passwordTextField.text = ""
        
        emailTextField.keyboardType = .emailAddress
        emailTextField.autocapitalizationType = .none
        emailTextField.autocorrectionType = .no
        emailTextField.returnKeyType = .next
        passwordTextField.returnKeyType = .done
        
        passwordTextField.isSecureTextEntry = true
        passwordTextField.autocapitalizationType = .none
        passwordTextField.autocorrectionType = .no
        
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "email",
            attributes: [.foregroundColor: UIColor.gray]
        )
        
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "password",
            attributes: [.foregroundColor: UIColor.gray]
        )
        
        styleTextField(emailTextField)
        styleTextField(passwordTextField)
        
        signUpButton.setTitle("Sign Up", for: .normal)
        signUpButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        signUpButton.backgroundColor = softBlue
        signUpButton.setTitleColor(.white, for: .normal)
        signUpButton.layer.cornerRadius = 12
        signUpButton.clipsToBounds = true
        
        signUpButton.configurationUpdateHandler = { button in
            button.backgroundColor = button.isHighlighted ? pressedBlue : softBlue
        }
    }
    
    func styleTextField(_ textField: UITextField) {
        textField.borderStyle = .none
        textField.backgroundColor = .secondarySystemBackground
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.systemGray4.cgColor
        
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 44))
        textField.leftView = paddingView
        textField.leftViewMode = .always
    }
    
    func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            completion?()
        }))
        present(alert, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        overrideUserInterfaceStyle = .light
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.becomeFirstResponder()
        } else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
            signUpPressed(signUpButton)
        }
        return true
    }
    
    @IBAction func signUpPressed(_ sender: UIButton) {
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let password = passwordTextField.text ?? ""
        guard !email.isEmpty, !password.isEmpty else {
            showAlert(title: "Missing Info", message: "Please enter email and password.")
            return
        }
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            guard let self = self else { return }
            if let error = error as NSError? {
                if let errorCode = AuthErrorCode(rawValue: error.code) {
                    switch errorCode {
                    case .emailAlreadyInUse:
                        self.showAlert(title: "Account Exists", message: "That email is already in use.")
                    case .invalidEmail:
                        self.showAlert(title: "Invalid Email", message: "Please enter a valid email.")
                    case .weakPassword:
                        self.showAlert(title: "Weak Password", message: "Password must be at least 6 characters.")
                    default:
                        self.showAlert(title: "Sign Up Failed", message: error.localizedDescription)
                    }
                } else {
                    self.showAlert(title: "Sign Up Failed", message: error.localizedDescription)
                }
                return
            }
            self.showAlert(title: "Success", message: "Account created. Please log in.") {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
