import Foundation

struct FitItem: Codable {
    let id: UUID
    let imageData: Data?
    let occasion: String
    let outfitType: String
    let notablePattern: String
    let shoes: String
    let weather: String
    let accessories: [String]
    let colors: [String]
    let overallRating: Double
    let outfitTypeScore: Int
    let patternScore: Int
    let colorScore: Int
    let shoesScore: Int
    let accessoriesScore: Int
    let vibeMatchScore: Int
    let comment: String
    let date: Date
}
