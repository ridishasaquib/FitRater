import Foundation
import FirebaseAuth

final class FitHistoryManager {

    static let shared = FitHistoryManager()

    private init() {}

    private func historyKey() -> String {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        return "\(uid)_fit_history"
    }

    func loadFits() -> [SavedFit] {
        guard let data = UserDefaults.standard.data(forKey: historyKey()) else {
            return []
        }

        do {
            return try JSONDecoder().decode([SavedFit].self, from: data)
        } catch {
            return []
        }
    }

    func saveFit(_ fit: SavedFit) {
        var fits = loadFits()
        fits.insert(fit, at: 0)
        saveAll(fits)
    }

    func deleteFit(id: UUID) {
        var fits = loadFits()
        fits.removeAll { $0.id == id }
        saveAll(fits)
    }

    private func saveAll(_ fits: [SavedFit]) {
        do {
            let data = try JSONEncoder().encode(fits)
            UserDefaults.standard.set(data, forKey: historyKey())
        } catch {
            print("Could not save fit history.")
        }
    }
}
