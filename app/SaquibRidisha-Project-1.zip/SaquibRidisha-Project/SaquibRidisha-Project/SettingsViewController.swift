//
//  SettingsViewController.swift
//  SaquibRidisha-Project
//
//  Created by Saquib, Ridisha N on 4/2/26.
//

import UIKit
import FirebaseAuth

class SettingsViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var appearanceLabel: UILabel!
    @IBOutlet weak var themeLabel: UILabel!
    @IBOutlet weak var themeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var feedbackLabel: UILabel!
    @IBOutlet weak var hapticsLabel: UILabel!
    @IBOutlet weak var hapticsSwitch: UISwitch!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var signOutButton: UIButton!
    @IBOutlet weak var strictnessLabel: UILabel!
    @IBOutlet weak var strictnessSegmentedControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
        loadSettings()
    }

    func styleUI() {
        view.backgroundColor = .systemBackground
        title = "Settings"

        titleLabel.text = "Settings"
        titleLabel.font = UIFont.systemFont(ofSize: 34, weight: .semibold)

        appearanceLabel.font = UIFont.systemFont(ofSize: 22, weight: .semibold)
        feedbackLabel.font = UIFont.systemFont(ofSize: 22, weight: .semibold)
        saveButton.layer.cornerRadius = 12
        saveButton.clipsToBounds = true
        saveButton.backgroundColor = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.65)
        saveButton.setTitleColor(.white, for: .normal)

        signOutButton.layer.cornerRadius = 12
        signOutButton.clipsToBounds = true
        signOutButton.backgroundColor = UIColor.systemPink.withAlphaComponent(0.15)
        signOutButton.setTitleColor(.systemPink, for: .normal)
    }

    func loadSettings() {
        let savedTheme = UserDefaults.standard.object(forKey: userKey("themeSelection")) as? Int ?? 0
        themeSegmentedControl.selectedSegmentIndex = savedTheme

        let savedHaptics = UserDefaults.standard.object(forKey: userKey("hapticsEnabled")) as? Bool ?? true
        hapticsSwitch.isOn = savedHaptics
        let savedStrictness = UserDefaults.standard.object(forKey: userKey("fitStrictness")) as? Int ?? 0
        strictnessSegmentedControl.selectedSegmentIndex = savedStrictness
    }

    func userKey(_ key: String) -> String {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        return "\(uid)_\(key)"
    }


    @IBAction func savePressed(_ sender: UIButton) {
        UserDefaults.standard.set(themeSegmentedControl.selectedSegmentIndex, forKey: userKey("themeSelection"))
        UserDefaults.standard.set(strictnessSegmentedControl.selectedSegmentIndex, forKey: userKey("fitStrictness"))
        UserDefaults.standard.set(hapticsSwitch.isOn, forKey: userKey("hapticsEnabled"))
        if themeSegmentedControl.selectedSegmentIndex == 0 {
            applyTheme(.light)
        } else {
            applyTheme(.dark)
        }
        let alert = UIAlertController(title: "Saved", message: "Your settings were saved.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    func applyTheme(_ style: UIUserInterfaceStyle) {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.overrideUserInterfaceStyle = style
        }
    }

    @IBAction func signOutPressed(_ sender: UIButton) {
        do {
            try Auth.auth().signOut()
            applyTheme(.light)
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            if let welcomeVC = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
                welcomeVC.modalPresentationStyle = .fullScreen
                self.present(welcomeVC, animated: true)
            }
        } catch {
            let alert = UIAlertController(title: "Sign Out Failed", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}
