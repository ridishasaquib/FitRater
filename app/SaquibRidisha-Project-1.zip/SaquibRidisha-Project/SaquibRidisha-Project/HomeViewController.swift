//
//  HomeViewController.swift
//  SaquibRidisha-Project
//
//  Created by Saquib, Ridisha N on 4/2/26.
//

import UIKit

class HomeViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var bowImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
    }

    func styleUI() {
        view.backgroundColor = UIColor.systemBackground
        title = "Home"

        titleLabel.text = "FitRater"
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 38) ?? UIFont.systemFont(ofSize: 38, weight: .bold)
        titleLabel.textColor = .label
    }
}
