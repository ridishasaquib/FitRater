import Foundation

struct SavedFit: Codable {
    let id: UUID
    let imageData: Data?
    let occasion: String
    let overallRating: Double
    let outfitTypeScore: Int
    let patternScore: Int
    let colorScore: Int
    let shoesScore: Int
    let accessoriesScore: Int
    let vibeMatchScore: Int
    let comment: String
    let date: Date
}
