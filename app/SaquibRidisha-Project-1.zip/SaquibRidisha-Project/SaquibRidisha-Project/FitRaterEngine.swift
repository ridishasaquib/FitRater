import Foundation

enum FitStrictness: Int {
    case easy = 0
    case normal = 1
}
struct FitRatingResult {
    let overallRating: Double
    let outfitTypeScore: Int
    let patternScore: Int
    let colorScore: Int
    let shoesScore: Int
    let accessoriesScore: Int
    let vibeMatchScore: Int
    let comment: String
}

final class FitRaterEngine {
    
    static func rateFit(
        occasion: String,
        outfitType: String,
        notablePattern: String,
        shoes: String,
        weather: String,
        accessories: [String],
        colors: [String],
        strictness: FitStrictness
    ) -> FitRatingResult {
        
        var outfitTypeScore = 5
        var patternScore = 5
        var colorScore = 5
        var shoesScore = 5
        var accessoriesScore = 5
        var vibeMatchScore = 5
        
        let strongOutfitMatches: [String: [String]] = [
            "Casual": ["Top and Jeans", "Top and Shorts", "Athleisure"],
            "Work": ["Blazer and Pants", "Dress Pants and Blouse", "Dress"],
            "School": ["Top and Jeans", "Athleisure", "Top and Shorts"],
            "Party": ["Dress", "Skirt and Top", "Heels Outfit"],
            "Gym": ["Workout Set", "Athleisure"],
            "Date": ["Dress", "Skirt and Top", "Top and Jeans"],
            "Professional": ["Blazer and Pants", "Dress Pants and Blouse"],
            "Beach": ["Swimsuit", "Cover-Up", "Top and Shorts"]
        ]
        
        let badOutfitMatches: [String: [String]] = [
            "Work": ["Top and Shorts", "Swimsuit", "Cover-Up", "Workout Set", "Athleisure"],
            "Professional": ["Top and Shorts", "Swimsuit", "Cover-Up", "Workout Set", "Athleisure"],
            "Gym": ["Dress", "Blazer and Pants", "Dress Pants and Blouse", "Heels Outfit"],
            "Beach": ["Blazer and Pants", "Dress Pants and Blouse", "Heels Outfit"],
            "Party": ["Workout Set", "Swimsuit"],
            "Date": ["Workout Set", "Swimsuit", "Cover-Up"]
        ]
        
        if strongOutfitMatches[occasion]?.contains(outfitType) == true {
            outfitTypeScore += 4
            vibeMatchScore += 2
        } else {
            outfitTypeScore -= 3
            vibeMatchScore -= 3
        }
        
        if badOutfitMatches[occasion]?.contains(outfitType) == true {
            outfitTypeScore -= 6
            vibeMatchScore -= 5
        }
        
        let strongShoeMatches: [String: [String]] = [
            "Casual": ["Sneakers", "Sandals", "Boots"],
            "Work": ["Loafers", "Heels", "Flats", "Boots"],
            "School": ["Sneakers", "Flats", "Boots"],
            "Party": ["Heels", "Boots", "Sandals"],
            "Gym": ["Sneakers"],
            "Date": ["Heels", "Boots", "Sandals", "Flats"],
            "Professional": ["Loafers", "Heels", "Flats", "Boots"],
            "Beach": ["Sandals", "Flip-Flops"]
        ]
        
        let badShoeMatches: [String: [String]] = [
            "Work": ["Flip-Flops", "Sneakers"],
            "Professional": ["Flip-Flops", "Sneakers", "Sandals"],
            "Gym": ["Heels", "Loafers", "Flip-Flops"],
            "Beach": ["Heels", "Loafers", "Boots"],
            "Party": ["Flip-Flops", "Sneakers"],
            "Date": ["Flip-Flops", "Sneakers"]
        ]
        
        if strongShoeMatches[occasion]?.contains(shoes) == true {
            shoesScore += 3
            vibeMatchScore += 1
        } else {
            shoesScore -= 3
            vibeMatchScore -= 2
        }
        
        if badShoeMatches[occasion]?.contains(shoes) == true {
            shoesScore -= 5
            vibeMatchScore -= 3
        }
        
        if notablePattern == "None" {
            patternScore += 2
        } else if ["Floral", "Plaid", "Polka Dots", "Striped", "Geometric"].contains(notablePattern) {
            patternScore += 2
        } else if ["Tie-Dye", "Animal Print", "Abstract"].contains(notablePattern) {
            patternScore += 1
        }
        
        if occasion == "Work" || occasion == "Professional" {
            if ["Tie-Dye", "Animal Print", "Abstract", "Polka Dots"].contains(notablePattern) {
                patternScore -= 3
                vibeMatchScore -= 2
            }
        }
        
        let neutralColors = ["Black", "White", "Gray", "Beige", "Brown"]
        let brightColors = ["Red", "Blue", "Green", "Pink", "Purple", "Yellow", "Orange"]
        
        let neutralCount = colors.filter { neutralColors.contains($0) }.count
        let brightCount = colors.filter { brightColors.contains($0) }.count
        
        if colors.isEmpty {
            colorScore -= 3
            vibeMatchScore -= 1
        } else if colors.count == 1 {
            colorScore += 1
        } else if colors.count >= 2 && colors.count <= 4 {
            colorScore += 3
        } else {
            colorScore -= 3
            vibeMatchScore -= 1
        }
        
        if neutralCount >= 1 && brightCount <= 2 {
            colorScore += 1
        }
        
        if brightCount >= 4 {
            colorScore -= 2
            vibeMatchScore -= 1
        }
        
        if occasion == "Work" || occasion == "Professional" {
            if brightCount >= 3 {
                colorScore -= 3
                vibeMatchScore -= 2
            }
        }
        
        if accessories.isEmpty {
            accessoriesScore -= 1
        } else if accessories.count <= 2 {
            accessoriesScore += 3
        } else if accessories.count <= 4 {
            accessoriesScore += 1
        } else {
            accessoriesScore -= 2
            vibeMatchScore -= 1
        }
        
        if occasion == "Work" || occasion == "Professional" {
            if accessories.contains("Sunglasses") || accessories.contains("Headwear") {
                accessoriesScore -= 2
                vibeMatchScore -= 1
            }
        }
        
        if weather == "Rainy" && (shoes == "Flip-Flops" || shoes == "Heels") {
            shoesScore -= 3
            vibeMatchScore -= 2
        }
        
        if weather == "Cold" {
            if ["Swimsuit", "Top and Shorts", "Cover-Up"].contains(outfitType) {
                outfitTypeScore -= 4
                vibeMatchScore -= 3
            }
            
            if accessories.contains("Jacket") {
                accessoriesScore += 2
                vibeMatchScore += 1
            } else {
                vibeMatchScore -= 1
            }
        }
        
        if weather == "Hot" {
            if outfitType == "Blazer and Pants" || outfitType == "Dress Pants and Blouse" {
                outfitTypeScore -= 2
                vibeMatchScore -= 1
            }
        }
        
        if weather == "Windy" {
            if outfitType == "Dress" || outfitType == "Skirt and Top" {
                vibeMatchScore -= 1
            }
        }
        
        if occasion == "Work" && outfitType == "Top and Shorts" {
            outfitTypeScore -= 6
            vibeMatchScore -= 5
        }
        
        if occasion == "Professional" && outfitType == "Top and Shorts" {
            outfitTypeScore -= 7
            vibeMatchScore -= 6
        }
        
        if occasion == "Gym" && shoes != "Sneakers" {
            shoesScore -= 5
            vibeMatchScore -= 3
        }
        
        if occasion == "Beach" && shoes == "Heels" {
            shoesScore -= 6
            vibeMatchScore -= 5
        }
        
        outfitTypeScore = clamp(outfitTypeScore)
        patternScore = clamp(patternScore)
        colorScore = clamp(colorScore)
        shoesScore = clamp(shoesScore)
        accessoriesScore = clamp(accessoriesScore)
        vibeMatchScore = clamp(vibeMatchScore)
        
        var overall = Double(
            outfitTypeScore * 3 +
            vibeMatchScore * 3 +
            shoesScore * 2 +
            patternScore +
            colorScore +
            accessoriesScore
        ) / 11.0

        if strictness == .easy {
            overall += 0.7
        }

        overall = max(1.0, min(10.0, overall))
        
        let comment: String
        
        switch overall {
        case 9.0...10.0:
            comment = "Excellent fit. The outfit, shoes, colors, and vibe all work together really well."
        case 8.0..<9.0:
            comment = "Strong look. It feels stylish and mostly matches the occasion."
        case 7.0..<8.0:
            comment = "Good outfit, but a few details could match the occasion better."
        case 6.0..<7.0:
            comment = "Decent fit, but the outfit needs better balance for this occasion."
        case 5.0..<6.0:
            comment = "This fit has potential, but some choices do not match the occasion well."
        default:
            comment = "This outfit does not fit the occasion very well. Try changing the outfit type, shoes, or color balance."
        }
        
        return FitRatingResult(
            overallRating: overall,
            outfitTypeScore: outfitTypeScore,
            patternScore: patternScore,
            colorScore: colorScore,
            shoesScore: shoesScore,
            accessoriesScore: accessoriesScore,
            vibeMatchScore: vibeMatchScore,
            comment: comment
        )
    }
    
    private static func clamp(_ value: Int) -> Int {
        return max(1, min(10, value))
    }
}
