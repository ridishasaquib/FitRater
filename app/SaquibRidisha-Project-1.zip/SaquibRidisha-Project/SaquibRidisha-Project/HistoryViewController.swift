import UIKit

class HistoryViewController: UIViewController {

    let titleLabel = UILabel()
    let tableView = UITableView()
    let emptyLabel = UILabel()

    var fits: [SavedFit] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadHistory()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground
        title = "History"

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.text = "Recent Fits"
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 36) ?? UIFont.systemFont(ofSize: 36, weight: .bold)
        titleLabel.textAlignment = .center

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "FitCell")
        tableView.rowHeight = 90

        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        emptyLabel.text = "No History"
        emptyLabel.textColor = .gray
        emptyLabel.font = UIFont.systemFont(ofSize: 28, weight: .medium)
        emptyLabel.textAlignment = .center

        view.addSubview(titleLabel)
        view.addSubview(tableView)
        view.addSubview(emptyLabel)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            tableView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            emptyLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    func loadHistory() {
        fits = FitHistoryManager.shared.loadFits()
        tableView.reloadData()

        emptyLabel.isHidden = !fits.isEmpty
        tableView.isHidden = fits.isEmpty
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }
}

extension HistoryViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        fits.count
    }

    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {

        let fit = fits[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "FitCell", for: indexPath)

        var content = UIListContentConfiguration.subtitleCell()
        content.text = "\(fit.occasion) - \(String(format: "%.1f", fit.overallRating))"
        content.secondaryText = formattedDate(fit.date)

        if let data = fit.imageData, let image = UIImage(data: data) {
            content.image = image
        } else {
            content.image = UIImage(systemName: "photo")
        }

        content.imageProperties.maximumSize = CGSize(width: 55, height: 55)
        content.textProperties.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        content.secondaryTextProperties.font = UIFont.systemFont(ofSize: 15)

        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let selectedFit = fits[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        if let detailVC = storyboard.instantiateViewController(withIdentifier: "HistoryDetailViewController") as? HistoryDetailViewController {
            detailVC.savedFit = selectedFit
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }
}
