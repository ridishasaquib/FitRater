import UIKit
import FirebaseAuth

class RateViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    let scrollView = UIScrollView()
    let contentStackView = UIStackView()
    
    let bowImageView = UIImageView()
    let titleLabel = UILabel()
    
    let topOccasionSegmentedControl = UISegmentedControl(items: ["Casual", "Work", "School", "Party"])
    let bottomOccasionSegmentedControl = UISegmentedControl(items: ["Gym", "Date", "Professional", "Beach"])
    
    let outfitTypeTextField = UITextField()
    let patternTextField = UITextField()
    let shoesTextField = UITextField()
    let weatherTextField = UITextField()
    
    let selectedImageView = UIImageView()
    let uploadPhotoButton = UIButton(type: .system)
    let rateMyFitButton = UIButton(type: .system)
    
    let outfitTypePicker = UIPickerView()
    let patternPicker = UIPickerView()
    let shoesPicker = UIPickerView()
    let weatherPicker = UIPickerView()
    
    let outfitTypes = [
        "Top and Shorts", "Dress", "Top and Jeans", "Athleisure",
        "Skirt and Top", "Workout Set", "Swimsuit", "Cover-Up",
        "Blazer and Pants", "Dress Pants and Blouse", "Heels Outfit"
    ]
    
    let patterns = [
        "None", "Floral", "Plaid", "Polka Dots", "Striped",
        "Animal Print", "Geometric", "Tie-Dye", "Abstract"
    ]
    
    let shoesOptions = [
        "Sneakers", "Sandals", "Heels", "Boots",
        "Loafers", "Flip-Flops", "Flats"
    ]
    
    let weatherOptions = [
        "Hot", "Warm", "Cool", "Cold", "Windy", "Rainy", "Cloudy", "Sunny"
    ]
    
    let accessoryNames = ["Necklace", "Watch/Bracelet", "Headwear", "Bag", "Sunglasses", "Jacket"]
    let colorNames = ["Black", "White", "Gray", "Beige", "Red", "Blue", "Green", "Pink", "Brown", "Purple", "Yellow", "Orange"]
    
    var accessorySwitches: [String: UISwitch] = [:]
    var colorSwitches: [String: UISwitch] = [:]
    
    var selectedImage: UIImage?
    var shouldResetForm = false
    var activeTextField: UITextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleBaseView()
        setupScrollView()
        setupTopSection()
        setupOccasionSection()
        setupDropdownFields()
        setupAccessoriesSection()
        setupColorsSection()
        setupPhotoSection()
        setupButtons()
        setupPickers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if shouldResetForm {
            resetRateForm()
            shouldResetForm = false
        }
    }
    
    func styleBaseView() {
        view.backgroundColor = .systemBackground
        title = "Rate"
    }
    
    func setupScrollView() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentStackView.translatesAutoresizingMaskIntoConstraints = false
        
        contentStackView.axis = .vertical
        contentStackView.spacing = 20
        contentStackView.alignment = .fill
        contentStackView.distribution = .fill
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentStackView)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            contentStackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor, constant: 16),
            contentStackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor, constant: 16),
            contentStackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor, constant: -16),
            contentStackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor, constant: -16),
            contentStackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor, constant: -32)
        ])
    }
    
    func setupTopSection() {
        bowImageView.translatesAutoresizingMaskIntoConstraints = false
        bowImageView.image = UIImage(named: "bowLogo")
        bowImageView.contentMode = .scaleAspectFit
        
        titleLabel.text = "Rate"
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "SnellRoundhand-Bold", size: 34) ?? UIFont.systemFont(ofSize: 34, weight: .bold)
        titleLabel.textColor = .label
        
        NSLayoutConstraint.activate([
            bowImageView.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        contentStackView.addArrangedSubview(bowImageView)
        contentStackView.addArrangedSubview(titleLabel)
    }
    
    func setupOccasionSection() {
        let occasionLabel = makeSectionLabel("Occasion")
        
        styleSegmentedControl(topOccasionSegmentedControl)
        styleSegmentedControl(bottomOccasionSegmentedControl)
        
        topOccasionSegmentedControl.addTarget(self, action: #selector(topOccasionChanged), for: .valueChanged)
        bottomOccasionSegmentedControl.addTarget(self, action: #selector(bottomOccasionChanged), for: .valueChanged)
        
        contentStackView.addArrangedSubview(occasionLabel)
        contentStackView.addArrangedSubview(topOccasionSegmentedControl)
        contentStackView.addArrangedSubview(bottomOccasionSegmentedControl)
    }
    
    func setupDropdownFields() {
        styleTextField(outfitTypeTextField, placeholder: "Outfit Type")
        styleTextField(patternTextField, placeholder: "Notable Pattern")
        styleTextField(shoesTextField, placeholder: "Shoes")
        styleTextField(weatherTextField, placeholder: "Weather")
        
        outfitTypeTextField.delegate = self
        patternTextField.delegate = self
        shoesTextField.delegate = self
        weatherTextField.delegate = self
        
        contentStackView.addArrangedSubview(outfitTypeTextField)
        contentStackView.addArrangedSubview(patternTextField)
        contentStackView.addArrangedSubview(shoesTextField)
        contentStackView.addArrangedSubview(weatherTextField)
    }
    
    func setupAccessoriesSection() {
        let label = makeSectionLabel("Accessories")
        contentStackView.addArrangedSubview(label)
        
        for name in accessoryNames {
            let row = makeToggleRow(title: name)
            accessorySwitches[name] = row.1
            contentStackView.addArrangedSubview(row.0)
        }
    }
    
    func setupColorsSection() {
        let label = makeSectionLabel("Colors")
        contentStackView.addArrangedSubview(label)
        
        for name in colorNames {
            let row = makeToggleRow(title: name)
            colorSwitches[name] = row.1
            contentStackView.addArrangedSubview(row.0)
        }
    }
    
    func setupPhotoSection() {
        let photoLabel = makeSectionLabel("Photo")
        
        selectedImageView.translatesAutoresizingMaskIntoConstraints = false
        selectedImageView.backgroundColor = .secondarySystemBackground
        selectedImageView.layer.cornerRadius = 16
        selectedImageView.clipsToBounds = true
        selectedImageView.contentMode = .scaleAspectFill
        
        NSLayoutConstraint.activate([
            selectedImageView.heightAnchor.constraint(equalToConstant: 180)
        ])
        
        contentStackView.addArrangedSubview(photoLabel)
        contentStackView.addArrangedSubview(selectedImageView)
    }
    
    func setupButtons() {
        styleButton(uploadPhotoButton, title: "Upload Photo")
        styleButton(rateMyFitButton, title: "Rate My Fit")
        
        uploadPhotoButton.addTarget(self, action: #selector(uploadPhotoPressed), for: .touchUpInside)
        rateMyFitButton.addTarget(self, action: #selector(rateMyFitPressed), for: .touchUpInside)
        
        rateMyFitButton.isEnabled = false
        rateMyFitButton.alpha = 0.5
        
        contentStackView.addArrangedSubview(uploadPhotoButton)
        contentStackView.addArrangedSubview(rateMyFitButton)
    }
    
    func setupPickers() {
        outfitTypePicker.delegate = self
        outfitTypePicker.dataSource = self
        
        patternPicker.delegate = self
        patternPicker.dataSource = self
        
        shoesPicker.delegate = self
        shoesPicker.dataSource = self
        
        weatherPicker.delegate = self
        weatherPicker.dataSource = self
        
        outfitTypeTextField.inputView = outfitTypePicker
        patternTextField.inputView = patternPicker
        shoesTextField.inputView = shoesPicker
        weatherTextField.inputView = weatherPicker
        
        addToolbar(to: outfitTypeTextField)
        addToolbar(to: patternTextField)
        addToolbar(to: shoesTextField)
        addToolbar(to: weatherTextField)
    }
    
    func makeSectionLabel(_ text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.textColor = .label
        return label
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField

        if textField == outfitTypeTextField && textField.text?.isEmpty == true {
            textField.text = outfitTypes[0]
        } else if textField == patternTextField && textField.text?.isEmpty == true {
            textField.text = patterns[0]
        } else if textField == shoesTextField && textField.text?.isEmpty == true {
            textField.text = shoesOptions[0]
        } else if textField == weatherTextField && textField.text?.isEmpty == true {
            textField.text = weatherOptions[0]
        }
        if textField == outfitTypeTextField {
            outfitTypePicker.selectRow(0, inComponent: 0, animated: false)
        } else if textField == patternTextField {
            patternPicker.selectRow(0, inComponent: 0, animated: false)
        } else if textField == shoesTextField {
            shoesPicker.selectRow(0, inComponent: 0, animated: false)
        } else if textField == weatherTextField {
            weatherPicker.selectRow(0, inComponent: 0, animated: false)
        }
    }
    func styleSegmentedControl(_ control: UISegmentedControl) {
        control.selectedSegmentIndex = UISegmentedControl.noSegment
    }
    
    func styleTextField(_ textField: UITextField, placeholder: String) {
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.borderStyle = .none
        textField.backgroundColor = .secondarySystemBackground
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.systemGray4.cgColor
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholder,
            attributes: [.foregroundColor: UIColor.gray]
        )
        
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 44))
        textField.leftView = paddingView
        textField.leftViewMode = .always
        
        NSLayoutConstraint.activate([
            textField.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    func styleButton(_ button: UIButton, title: String) {
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont(name: "SnellRoundhand-Bold", size: 24) ?? UIFont.systemFont(ofSize: 22, weight: .semibold)
        button.backgroundColor = UIColor(red: 169/255, green: 199/255, blue: 238/255, alpha: 0.85)
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 12
        button.clipsToBounds = true
        
        NSLayoutConstraint.activate([
            button.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    func makeToggleRow(title: String) -> (UIStackView, UISwitch) {
        let label = UILabel()
        label.text = title
        label.font = UIFont.systemFont(ofSize: 17)
        
        let toggle = UISwitch()
        
        let row = UIStackView(arrangedSubviews: [label, toggle])
        row.axis = .horizontal
        row.alignment = .center
        row.distribution = .equalSpacing
        
        return (row, toggle)
    }
    
    func addToolbar(to textField: UITextField) {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(
            title: "Done",
            style: .plain,
            target: self,
            action: #selector(donePicker)
        )
        
        toolbar.setItems([doneButton], animated: false)
        textField.inputAccessoryView = toolbar
    }
    
    @objc func donePicker() {
        triggerHaptic()
        view.endEditing(true)
    }
    
    @objc func topOccasionChanged() {
        triggerHaptic()
        
        if topOccasionSegmentedControl.selectedSegmentIndex != UISegmentedControl.noSegment {
            bottomOccasionSegmentedControl.selectedSegmentIndex = UISegmentedControl.noSegment
        }
    }
    
    @objc func bottomOccasionChanged() {
        triggerHaptic()
        
        if bottomOccasionSegmentedControl.selectedSegmentIndex != UISegmentedControl.noSegment {
            topOccasionSegmentedControl.selectedSegmentIndex = UISegmentedControl.noSegment
        }
    }
    
    func selectedOccasion() -> String? {
        if topOccasionSegmentedControl.selectedSegmentIndex != UISegmentedControl.noSegment {
            return topOccasionSegmentedControl.titleForSegment(at: topOccasionSegmentedControl.selectedSegmentIndex)
        }
        
        if bottomOccasionSegmentedControl.selectedSegmentIndex != UISegmentedControl.noSegment {
            return bottomOccasionSegmentedControl.titleForSegment(at: bottomOccasionSegmentedControl.selectedSegmentIndex)
        }
        
        return nil
    }
    
    func selectedAccessories() -> [String] {
        accessorySwitches.compactMap { $0.value.isOn ? $0.key : nil }
    }
    
    func selectedColors() -> [String] {
        colorSwitches.compactMap { $0.value.isOn ? $0.key : nil }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Missing Info", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    @objc func uploadPhotoPressed() {
        triggerHaptic()
        
        let actionSheet = UIAlertController(title: "Upload Photo", message: nil, preferredStyle: .actionSheet)
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            actionSheet.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { _ in
                self.openImagePicker(sourceType: .photoLibrary)
            }))
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
                self.openImagePicker(sourceType: .camera)
            }))
        }
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        if let popover = actionSheet.popoverPresentationController {
            popover.sourceView = uploadPhotoButton
            popover.sourceRect = uploadPhotoButton.bounds
        }
        
        present(actionSheet, animated: true)
    }
    
    func openImagePicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = sourceType
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]
    ) {
        let image = (info[.editedImage] ?? info[.originalImage]) as? UIImage
        
        if let image = image {
            selectedImage = image
            selectedImageView.image = image
            uploadPhotoButton.setTitle("Change Photo", for: .normal)
            
            rateMyFitButton.isEnabled = true
            rateMyFitButton.alpha = 1.0
        }
        
        dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    @objc func rateMyFitPressed() {
        triggerHaptic()
        
        guard let occasion = selectedOccasion() else {
            showAlert(message: "Please select an occasion.")
            return
        }
        
        guard let outfitType = outfitTypeTextField.text, !outfitType.isEmpty else {
            showAlert(message: "Please select an outfit type.")
            return
        }
        
        guard let pattern = patternTextField.text, !pattern.isEmpty else {
            showAlert(message: "Please select a notable pattern.")
            return
        }
        
        guard let shoes = shoesTextField.text, !shoes.isEmpty else {
            showAlert(message: "Please select shoes.")
            return
        }
        
        guard let weather = weatherTextField.text, !weather.isEmpty else {
            showAlert(message: "Please select weather.")
            return
        }
        
        guard let selectedImage = selectedImage else {
            showAlert(message: "Please upload a photo.")
            return
        }
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        let strictnessRaw = UserDefaults.standard.object(forKey: "\(uid)_fitStrictness") as? Int ?? 0
        let strictness = FitStrictness(rawValue: strictnessRaw) ?? .easy
        let result = FitRaterEngine.rateFit(
            occasion: occasion,
            outfitType: outfitType,
            notablePattern: pattern,
            shoes: shoes,
            weather: weather,
            accessories: selectedAccessories(),
            colors: selectedColors(),
            strictness: strictness
        )
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if let scanVC = storyboard.instantiateViewController(withIdentifier: "FitScanViewController") as? FitScanViewController {
            scanVC.selectedImage = selectedImage
            scanVC.ratingResult = result
            scanVC.strictness = strictness
            scanVC.occasion = occasion
            navigationController?.pushViewController(scanVC, animated: true)
        }
    }
    
    func resetRateForm() {
        topOccasionSegmentedControl.selectedSegmentIndex = UISegmentedControl.noSegment
        bottomOccasionSegmentedControl.selectedSegmentIndex = UISegmentedControl.noSegment
        
        outfitTypeTextField.text = ""
        patternTextField.text = ""
        shoesTextField.text = ""
        weatherTextField.text = ""
        
        for toggle in accessorySwitches.values {
            toggle.isOn = false
        }
        
        for toggle in colorSwitches.values {
            toggle.isOn = false
        }
        
        selectedImage = nil
        selectedImageView.image = nil
        selectedImageView.backgroundColor = .secondarySystemBackground
        
        uploadPhotoButton.setTitle("Upload Photo", for: .normal)
        
        rateMyFitButton.isEnabled = false
        rateMyFitButton.alpha = 0.5
        
        view.endEditing(true)
    }
    
    func triggerHaptic() {
        let uid = Auth.auth().currentUser?.uid ?? "guest"
        let enabled = UserDefaults.standard.object(forKey: "\(uid)_hapticsEnabled") as? Bool ?? true
        
        if enabled {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
        }
    }
    
    func textField(
        _ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String
    ) -> Bool {
        return false
    }
}

extension RateViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == outfitTypePicker {
            return outfitTypes.count
        } else if pickerView == patternPicker {
            return patterns.count
        } else if pickerView == shoesPicker {
            return shoesOptions.count
        } else if pickerView == weatherPicker {
            return weatherOptions.count
        }
        
        return 0
    }
    
    func pickerView(
        _ pickerView: UIPickerView,
        titleForRow row: Int,
        forComponent component: Int
    ) -> String? {
        if pickerView == outfitTypePicker {
            return outfitTypes[row]
        } else if pickerView == patternPicker {
            return patterns[row]
        } else if pickerView == shoesPicker {
            return shoesOptions[row]
        } else if pickerView == weatherPicker {
            return weatherOptions[row]
        }
        
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        triggerHaptic()
        
        if pickerView == outfitTypePicker {
            outfitTypeTextField.text = outfitTypes[row]
        } else if pickerView == patternPicker {
            patternTextField.text = patterns[row]
        } else if pickerView == shoesPicker {
            shoesTextField.text = shoesOptions[row]
        } else if pickerView == weatherPicker {
            weatherTextField.text = weatherOptions[row]
        }
    }
}
