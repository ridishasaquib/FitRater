//
//  SaquibRidisha_ProjectTests.swift
//  SaquibRidisha-ProjectTests
//
//  Created by Saquib, Ridisha N on 3/31/26.
//

import Testing
@testable import SaquibRidisha_Project

struct SaquibRidisha_ProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
